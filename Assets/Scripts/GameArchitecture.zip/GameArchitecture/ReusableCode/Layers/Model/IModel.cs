using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/// <summary>
/// 模型层接口
/// </summary>
public interface IModel : INeedInit,ICanGetUtility,ICanSendEvent
{

}
