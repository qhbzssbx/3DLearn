using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/// <summary>
/// 工具层接口
/// </summary>
public interface IUtility : INeedInit
{

}
