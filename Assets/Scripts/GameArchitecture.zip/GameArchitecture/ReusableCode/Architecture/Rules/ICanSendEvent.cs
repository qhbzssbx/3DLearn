using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/// <summary>
/// 允许发送事件
/// </summary>
public interface ICanSendEvent
{

}
