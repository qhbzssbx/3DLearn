using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/// <summary>
/// 允许发送命令
/// </summary>
public interface ICanSendCommand
{

}
