using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/// <summary>
/// 该对象属于游戏框架
/// </summary>
public interface IBelongToArchitecture
{

}
