using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/// <summary>
/// 允许注册注销事件
/// </summary>
public interface ICanRegistAndUnRegistEvent
{

}
