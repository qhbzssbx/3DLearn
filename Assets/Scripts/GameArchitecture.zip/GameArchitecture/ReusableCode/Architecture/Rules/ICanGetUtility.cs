using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/// <summary>
/// 允许访问工具层
/// </summary>
public interface ICanGetUtility : IBelongToArchitecture
{

}
