using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/// <summary>
/// 允许销毁
/// </summary>
public interface INeedDestory
{
    public void OnDestroy();
}
