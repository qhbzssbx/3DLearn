using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/// <summary>
/// 允许对象初始化的接口
/// </summary>
public interface INeedInit
{
    public void Init();
}
