using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// UI系统接口
/// </summary>
public interface IUISystem : ISystem
{
}
