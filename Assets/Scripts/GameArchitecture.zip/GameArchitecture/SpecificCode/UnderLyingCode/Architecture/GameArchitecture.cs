using System.Collections;
using System.Collections.Generic;
using GF;
using UnityEngine;
/// <summary>
/// 游戏框架入口
/// </summary>
public class GameArchitecture : Architecture<GameArchitecture>
{
    protected override void Init()
    {
        this.RegistSystem<ISystem>(new AssetSystem());
        this.RegistSystem<IUISystem>(new UISystem());
    }
}

